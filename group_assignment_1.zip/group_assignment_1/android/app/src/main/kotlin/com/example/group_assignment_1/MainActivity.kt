package com.example.group_assignment_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
