import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/application_model.dart';

class ApplicationService {
  final SupabaseClient _supabase = Supabase.instance.client;

  Future<List<ApplicationModel>> fetchStudentApplications(
    String studentId,
  ) async {
    final response = await _supabase
        .from('applications')
        .select()
        .eq('student_id', studentId)
        .order('created_at', ascending: false);

    return (response as List).map((e) => ApplicationModel.fromMap(e)).toList();
  }

  Future<bool> createApplication({
    required String studentId,
    required int yearOfStudy,
    required String primaryModuleCode,
    required String primaryModuleName,
    required String secondaryModuleCode,
    required String secondaryModuleName,
    required String cvURL,
    required String transcriptURL,
    required String motivation,
    required bool eligibilityConfirmed,
  }) async {
    try {
      await _supabase.from('applications').insert({
        'student_id': studentId,
        'current_year_of_study': yearOfStudy,
        'primary_module_code': primaryModuleCode,
        'primary_module_name': primaryModuleName,
        'secondary_module_code':
            secondaryModuleCode.isEmpty ? null : secondaryModuleCode,
        'secondary_module_name':
            secondaryModuleName.isEmpty ? null : secondaryModuleName,
        'cv_url': cvURL,
        'transcript_url': transcriptURL,
        'motivation': motivation,
        'eligibility_confirmed': eligibilityConfirmed,
        'status': 'submitted',
      });

      return true;
    } catch (e) {
      throw Exception('createApplication failed: $e');
    }
  }

  Future<bool> updateApplication({
    required String applicationId,
    required String primaryModuleCode,
    required String primaryModuleName,
    required String secondaryModuleCode,
    required String secondaryModuleName,
    required String cvURL,
    required String transcriptURL,
    required String motivation,
  }) async {
    try {
      await _supabase
          .from('applications')
          .update({
            'primary_module_code': primaryModuleCode,
            'primary_module_name': primaryModuleName,
            'secondary_module_code':
                secondaryModuleCode.isEmpty ? null : secondaryModuleCode,
            'secondary_module_name':
                secondaryModuleName.isEmpty ? null : secondaryModuleName,
            'cv_url': cvURL,
            'transcript_url': transcriptURL,
            'motivation': motivation,
            'status': 'submitted',
            'updated_at': DateTime.now().toIso8601String(),
          })
          .eq('id', applicationId);

      return true;
    } catch (e) {
      throw Exception('updateApplication failed: $e');
    }
  }

  Future<bool> updateApplicationStatus({
    required String applicationId,
    required String status,
  }) async {
    try {
      await _supabase
          .from('applications')
          .update({
            'status': status,
            'updated_at': DateTime.now().toIso8601String(),
          })
          .eq('id', applicationId);

      return true;
    } catch (e) {
      throw Exception('updateApplicationStatus failed: $e');
    }
  }

  Future<ApplicationModel?> getApplicationById(String applicationId) async {
    final response =
        await _supabase
            .from('applications')
            .select()
            .eq('id', applicationId)
            .maybeSingle();

    if (response == null) return null;

    return ApplicationModel.fromMap(response);
  }

  Future<bool> deleteApplication(String applicationId) async {
    try {
      await _supabase.from('applications').delete().eq('id', applicationId);

      return true;
    } catch (e) {
      throw Exception('deleteApplication failed: $e');
    }
  }

  Future<List<Map<String, dynamic>>> fetchAllApplications() async {
    final response = await _supabase
        .from('applications')
        .select('*, profiles(*)')
        .order('created_at', ascending: false);

    return List<Map<String, dynamic>>.from(response);
  }
}
