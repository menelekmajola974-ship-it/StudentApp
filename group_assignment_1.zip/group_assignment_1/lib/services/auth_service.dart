import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/user_model.dart';
import 'package:image_picker/image_picker.dart';

class AuthService {
  final _supabase = Supabase.instance.client;

  User? get currentUser => _supabase.auth.currentUser;

  Future<UserModel?> signIn(String email, String password) async {
    final response = await _supabase.auth.signInWithPassword(
      email: email,
      password: password,
    );

    if (response.user == null) {
      return null;
    }

    return await _fetchProfile(response.user!.id);
  }

  Future<UserModel?> signUp({
    required String email,
    required String password,
    required String name,
    required String surname,
    required int studentNumber,
  }) async {
    final response = await _supabase.auth.signUp(
      email: email,
      password: password,
    );

    if (response.user == null) {
      return null;
    }

    final userId = response.user!.id;

    await _supabase.from('profiles').insert({
      'user_id': userId,
      'name': name,
      'surname': surname,
      'student_number': studentNumber,
      'email': email,
      'role': 'student',
      'created_at': DateTime.now().toIso8601String(),
    });

    return await _fetchProfile(userId);
  }

  Future<void> signOut() async {
    await _supabase.auth.signOut();
  }

  Future<UserModel?> getCurrentProfile() async {
    final user = _supabase.auth.currentUser;

    if (user == null) {
      return null;
    }

    return await _fetchProfile(user.id);
  }

  Future<UserModel?> _fetchProfile(String userId) async {
    final data =
        await _supabase
            .from('profiles')
            .select()
            .eq('user_id', userId)
            .single();

    return UserModel.fromMap(data);
  }

  Future<String?> uploadAvatar(String userId, XFile imageFile) async {
    final bytes = await imageFile.readAsBytes();
    final filePath = '$userId/avatar.jpg';

    await _supabase.storage
        .from('avatars')
        .uploadBinary(
          filePath,
          bytes,
          fileOptions: const FileOptions(
            contentType: 'image/jpeg',
            upsert: true,
          ),
        );

    final publicUrl = _supabase.storage.from('avatars').getPublicUrl(filePath);

    final urlWithBuster =
        '$publicUrl?t=${DateTime.now().millisecondsSinceEpoch}';

    await _supabase
        .from('profiles')
        .update({'avatar_url': urlWithBuster})
        .eq('user_id', userId);

    return urlWithBuster;
  }
}
