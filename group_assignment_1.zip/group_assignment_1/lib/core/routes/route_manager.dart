import 'package:flutter/material.dart';
import '../../view/auth/login_screen.dart';
import '../../view/auth/signup_screen.dart';
import '../../view/student/home_screen.dart';
import '../../view/student/aplication_form_screen.dart';
import '../../view/student/application_detail_screen.dart';
import '../../view/admin/admin_dashboard.dart';

class RouteManager {
  static const String login = '/';
  static const String signup = '/signup';
  static const String home = '/home';
  static const String applicationForm = '/application-form';
  static const String applicationDetail = '/application-detail';
  static const String adminDashboard = '/admin-dashboard';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case login:
        return MaterialPageRoute(builder: (_) => const LoginScreen());

      case signup:
        return MaterialPageRoute(builder: (_) => const SignupScreen());

      case home:
        return MaterialPageRoute(builder: (_) => const HomeScreen());

      case applicationForm:
        final String? applicationId = settings.arguments as String?;
        return MaterialPageRoute(
          builder: (_) => ApplicationFormScreen(applicationId: applicationId),
        );

      case applicationDetail:
        final String applicationId = settings.arguments as String;
        return MaterialPageRoute(
          builder: (_) => ApplicationDetailScreen(applicationId: applicationId),
        );

      case adminDashboard:
        return MaterialPageRoute(builder: (_) => const AdminDashboardScreen());

      default:
        return MaterialPageRoute(
          builder:
              (_) => Scaffold(
                body: Center(
                  child: Text('No route defined for ${settings.name}'),
                ),
              ),
        );
    }
  }
}
