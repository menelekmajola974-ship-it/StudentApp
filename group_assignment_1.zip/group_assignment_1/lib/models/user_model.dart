class UserModel {
  final String id;
  final String userId;

  final String name;
  final String surname;

  final int studentNumber;

  final String email;

  final String role;

  final String? avatarUrl;

  final DateTime? createdAt;

  UserModel({
    required this.id,
    required this.userId,
    required this.name,
    required this.surname,
    required this.studentNumber,
    required this.email,
    required this.role,
    required this.avatarUrl,
    this.createdAt,
  });

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      id: map['id'] as String,

      userId: map['user_id'] as String,

      name: map['name'] as String,

      surname: map['surname'] as String,

      studentNumber: map['student_number'] as int,

      email: map['email'] as String,

      role: map['role'] as String,

      avatarUrl: map['avatar_url'] as String?,

      createdAt:
          map['created_at'] != null
              ? DateTime.parse(map['created_at'] as String)
              : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,

      'user_id': userId,

      'name': name,

      'surname': surname,

      'student_number': studentNumber,

      'email': email,

      'role': role,

      'avatar_url': avatarUrl,

      'created_at': createdAt?.toIso8601String(),
    };
  }

  bool get isAdmin => role == 'admin';

  bool get isStudent => role == 'student';
}
