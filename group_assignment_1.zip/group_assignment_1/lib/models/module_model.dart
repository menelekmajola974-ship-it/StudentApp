class ModuleConstants {
  static const Map<int, List<Map<String, String>>> modulesByYear = {
    1: [
      {'code': 'PIM', 'name': 'Personal Information Management'},
      {'code': 'LCS', 'name': 'Academic Literacy and Communication Studies'},
      {'code': 'ITE', 'name': 'Information Technology Essentials'},
      {'code': 'ITM', 'name': 'Information Technology Mathematics'},
      {'code': 'PSA', 'name': 'Problem Solving and Algorithms'},
      {'code': 'SOD', 'name': 'Software Development'},
      {'code': 'INP', 'name': 'Internet Programming'},
    ],

    2: [
      {'code': 'DBS', 'name': 'Databases'},
      {'code': 'SOE', 'name': 'Software Engineering'},
      {'code': 'GUD', 'name': 'Graphical Design'},
      {'code': 'SOD', 'name': 'Software Development'},
      {'code': 'TPG', 'name': 'Technical Programming'},
      {'code': 'WEB', 'name': 'Web Content Management'},
      {'code': 'INT', 'name': 'Internet Technologies'},
    ],

    3: [
      {'code': 'SOD', 'name': 'Software Development'},
      {'code': 'SOE', 'name': 'Software Engineering'},
      {'code': 'TPG', 'name': 'Technical Programming'},
      {'code': 'CMN', 'name': 'Communication Networks'},
      {'code': 'ITS', 'name': 'Information Technology and Society'},
    ],
  };

  static List<Map<String, String>> get allModules {
    return modulesByYear.values.expand((e) => e).toList();
  }
}
