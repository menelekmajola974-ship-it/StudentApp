class DocumentModel {
  final String id;
  final String applicationId;
  final String fileUrl;
  final String fileName;
  final DateTime? uploadedAt;

  DocumentModel({
    required this.id,
    required this.applicationId,
    required this.fileUrl,
    required this.fileName,
    this.uploadedAt,
  });

  factory DocumentModel.fromMap(Map<String, dynamic> map) {
    return DocumentModel(
      id: map['id'] as String,
      applicationId: map['application_id'] as String,
      fileUrl: map['file_url'] as String,
      fileName: map['file_name'] as String,
      uploadedAt:
          map['uploaded_at'] != null
              ? DateTime.parse(map['uploaded_at'] as String)
              : null,
    );
  }

  Map<String, dynamic> toMap() => {
    'application_id': applicationId,
    'file_url': fileUrl,
    'file_name': fileName,
  };
}
