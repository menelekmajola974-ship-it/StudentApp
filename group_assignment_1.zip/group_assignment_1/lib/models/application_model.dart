import 'module_model.dart';
import 'document_model.dart';

class ApplicationModel {
  final String id;

  final String studentId;

  final int currentYearOfStudy;

  final String primaryModuleCode;
  final String primaryModuleName;

  final String? secondaryModuleCode;
  final String? secondaryModuleName;

  final String cvUrl;
  final String transcriptUrl;

  final String motivation;

  final bool eligibilityConfirmed;

  final String status;

  final DateTime? createdAt;

  ApplicationModel({
    required this.id,
    required this.studentId,
    required this.currentYearOfStudy,

    required this.primaryModuleCode,
    required this.primaryModuleName,

    this.secondaryModuleCode,
    this.secondaryModuleName,

    required this.cvUrl,
    required this.transcriptUrl,

    required this.motivation,

    required this.eligibilityConfirmed,

    required this.status,

    this.createdAt,
  });

  factory ApplicationModel.fromMap(Map<String, dynamic> map) {
    return ApplicationModel(
      id: map['id'] ?? '',

      studentId: map['student_id'] ?? '',

      currentYearOfStudy: map['current_year_of_study'] ?? 1,

      primaryModuleCode: map['primary_module_code'] ?? '',

      primaryModuleName: map['primary_module_name'] ?? '',

      secondaryModuleCode: map['secondary_module_code'],

      secondaryModuleName: map['secondary_module_name'],

      cvUrl: map['cv_url'] ?? '',

      transcriptUrl: map['transcript_url'] ?? '',

      motivation: map['motivation'] ?? '',

      eligibilityConfirmed: map['eligibility_confirmed'] ?? false,

      status: map['status'] ?? 'submitted',

      createdAt:
          map['created_at'] != null ? DateTime.parse(map['created_at']) : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'student_id': studentId,

      'current_year_of_study': currentYearOfStudy,

      'primary_module_code': primaryModuleCode,

      'primary_module_name': primaryModuleName,

      'secondary_module_code': secondaryModuleCode,

      'secondary_module_name': secondaryModuleName,

      'cv_url': cvUrl,

      'transcript_url': transcriptUrl,

      'motivation': motivation,

      'eligibility_confirmed': eligibilityConfirmed,

      'status': status,
    };
  }

  bool get isSubmitted => status.toLowerCase() == 'submitted';

  bool get isInProgress => status.toLowerCase() == 'in progress';

  bool get isApproved => status.toLowerCase() == 'approved';

  bool get isRejected => status.toLowerCase() == 'rejected';

  bool get needsResubmission => status.toLowerCase() == 'needs resubmission';

  bool get hasCv => cvUrl.trim().isNotEmpty;

  bool get hasTranscript => transcriptUrl.trim().isNotEmpty;

  bool get documentsUploaded => hasCv && hasTranscript;

  bool get hasSecondaryModule =>
      secondaryModuleCode != null && secondaryModuleCode!.isNotEmpty;
}
