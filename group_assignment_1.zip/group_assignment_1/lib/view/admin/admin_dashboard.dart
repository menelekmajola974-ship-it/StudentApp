import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../viewmodels/application_viewmodel.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  String _statusFilter = 'all';
  int? _yearFilter;
  String? _moduleFilter;
  bool _newestFirst = true;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ApplicationViewModel>().loadAllApplications();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _applyFilters(List<Map<String, dynamic>> all) {
    var list = [...all];

    if (_statusFilter != 'all') {
      list = list.where((a) => a['status'] == _statusFilter).toList();
    }

    if (_yearFilter != null) {
      list =
          list.where((a) => a['current_year_of_study'] == _yearFilter).toList();
    }

    if (_moduleFilter != null && _moduleFilter!.isNotEmpty) {
      final q = _moduleFilter!.toLowerCase();
      list =
          list.where((a) {
            final primary =
                (a['primary_module_code'] ?? '').toString().toLowerCase();
            final secondary =
                (a['secondary_module_code'] ?? '').toString().toLowerCase();
            return primary.contains(q) || secondary.contains(q);
          }).toList();
    }

    if (_searchQuery.isNotEmpty) {
      final q = _searchQuery.toLowerCase();
      list =
          list.where((a) {
            final profile = a['profiles'] as Map<String, dynamic>?;
            final name =
                '${profile?['name'] ?? ''} ${profile?['surname'] ?? ''}'
                    .toLowerCase();
            final number = (profile?['student_number'] ?? '').toString();
            return name.contains(q) || number.contains(q);
          }).toList();
    }

    list.sort((a, b) {
      final aDate = DateTime.tryParse(a['created_at'] ?? '') ?? DateTime(0);
      final bDate = DateTime.tryParse(b['created_at'] ?? '') ?? DateTime(0);
      return _newestFirst ? bDate.compareTo(aDate) : aDate.compareTo(bDate);
    });

    return list;
  }

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'approved':
        return Colors.green;
      case 'rejected':
        return Colors.red;
      case 'in_progress':
        return Colors.blue;
      case 'submitted':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  Map<String, int> _buildStats(List<Map<String, dynamic>> all) {
    return {
      'total': all.length,
      'submitted': all.where((a) => a['status'] == 'submitted').length,
      'approved': all.where((a) => a['status'] == 'approved').length,
      'rejected': all.where((a) => a['status'] == 'rejected').length,
    };
  }

  Future<void> _updateStatus(String id, String status) async {
    final vm = context.read<ApplicationViewModel>();
    final success =
        status == 'approved'
            ? await vm.approveApplication(id)
            : await vm.rejectApplication(id);

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          success
              ? 'Application ${status == 'approved' ? 'approved' : 'rejected'}'
              : 'Failed to update status',
        ),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );
  }

  Future<void> _deleteApplication(String id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder:
          (ctx) => AlertDialog(
            title: const Text('Delete Application'),
            content: const Text('This cannot be undone. Are you sure?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Cancel'),
              ),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: Colors.red),
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Delete'),
              ),
            ],
          ),
    );

    if (confirmed != true || !mounted) return;

    final vm = context.read<ApplicationViewModel>();
    final success = await vm.adminDeleteApplication(id);

    if (!mounted) return;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(success ? 'Application deleted' : 'Failed to delete'),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );
  }

  Future<void> _openDocument(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Could not open document')));
    }
  }

  void _showDetail(Map<String, dynamic> app) {
    final profile = app['profiles'] as Map<String, dynamic>? ?? {};
    final status = app['status'] ?? '';
    final color = _statusColor(status);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.75,
          maxChildSize: 0.95,
          builder: (_, scrollController) {
            return ListView(
              controller: scrollController,
              padding: const EdgeInsets.all(24),
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                Row(
                  children: [
                    CircleAvatar(
                      radius: 28,
                      backgroundColor: Colors.indigo.shade50,
                      child: Text(
                        (profile['name'] ?? 'U')
                            .toString()
                            .substring(0, 1)
                            .toUpperCase(),
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.indigo,
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${profile['name'] ?? ''} ${profile['surname'] ?? ''}',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Student No: ${profile['student_number'] ?? ''}',
                            style: TextStyle(
                              color: Colors.grey.shade600,
                              fontSize: 13,
                            ),
                          ),
                          Text(
                            profile['email'] ?? '',
                            style: TextStyle(
                              color: Colors.grey.shade600,
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: color),
                  ),
                  child: Text(
                    status.toUpperCase(),
                    style: TextStyle(color: color, fontWeight: FontWeight.bold),
                  ),
                ),

                const Divider(height: 30),

                _detailRow(
                  'Year of Study',
                  'Year ${app['current_year_of_study'] ?? '-'}',
                ),
                _detailRow(
                  'Primary Module',
                  '${app['primary_module_code'] ?? ''} - ${app['primary_module_name'] ?? ''}',
                ),
                if ((app['secondary_module_code'] ?? '').toString().isNotEmpty)
                  _detailRow(
                    'Secondary Module',
                    '${app['secondary_module_code']} - ${app['secondary_module_name'] ?? ''}',
                  ),
                _detailRow('Submitted', _formatDate(app['created_at'])),

                const Divider(height: 30),

                const Text(
                  'Motivation',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    app['motivation'] ?? '',
                    style: const TextStyle(height: 1.5),
                  ),
                ),

                const Divider(height: 30),

                const Text(
                  'Documents',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                _docButton('CV', app['cv_url'] ?? ''),
                const SizedBox(height: 8),
                _docButton('Academic Transcript', app['transcript_url'] ?? ''),

                const Divider(height: 30),

                if (status != 'approved')
                  FilledButton.icon(
                    onPressed: () async {
                      Navigator.pop(ctx);
                      await _updateStatus(app['id'], 'approved');
                    },
                    style: FilledButton.styleFrom(
                      backgroundColor: Colors.green,
                      minimumSize: const Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    icon: const Icon(Icons.check_circle_outline),
                    label: const Text('Approve Application'),
                  ),

                if (status != 'approved') const SizedBox(height: 10),

                if (status != 'rejected')
                  OutlinedButton.icon(
                    onPressed: () async {
                      Navigator.pop(ctx);
                      await _updateStatus(app['id'], 'rejected');
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.red,
                      side: const BorderSide(color: Colors.red),
                      minimumSize: const Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    icon: const Icon(Icons.cancel_outlined),
                    label: const Text('Reject Application'),
                  ),

                const SizedBox(height: 10),

                OutlinedButton.icon(
                  onPressed: () => _deleteApplication(app['id']),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.red.shade800,
                    side: BorderSide(color: Colors.red.shade800),
                    minimumSize: const Size(double.infinity, 50),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  icon: const Icon(Icons.delete_outline),
                  label: const Text('Delete Application'),
                ),

                const SizedBox(height: 30),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      appBar: AppBar(
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: const Text(
          'Admin Dashboard',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed:
                () =>
                    context.read<ApplicationViewModel>().loadAllApplications(),
          ),
        ],
      ),
      body: Consumer<ApplicationViewModel>(
        builder: (context, vm, _) {
          if (vm.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          final all = vm.allApplications;
          final stats = _buildStats(all);
          final filtered = _applyFilters(all);

          final modules =
              all
                  .map((a) => a['primary_module_code']?.toString() ?? '')
                  .where((c) => c.isNotEmpty)
                  .toSet()
                  .toList()
                ..sort();

          return RefreshIndicator(
            onRefresh: () => vm.loadAllApplications(),
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Row(
                  children: [
                    _statCard('Total', '${stats['total']}', Colors.indigo),
                    _statCard(
                      'Submitted',
                      '${stats['submitted']}',
                      Colors.orange,
                    ),
                    _statCard('Approved', '${stats['approved']}', Colors.green),
                    _statCard('Rejected', '${stats['rejected']}', Colors.red),
                  ],
                ),

                const SizedBox(height: 16),

                TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search by name or student number...',
                    prefixIcon: const Icon(Icons.search),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide.none,
                    ),
                    suffixIcon:
                        _searchQuery.isNotEmpty
                            ? IconButton(
                              icon: const Icon(Icons.close),
                              onPressed:
                                  () => setState(() {
                                    _searchController.clear();
                                    _searchQuery = '';
                                  }),
                            )
                            : null,
                  ),
                  onChanged: (val) => setState(() => _searchQuery = val),
                ),

                const SizedBox(height: 12),

                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Status',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        children: [
                          for (final s in [
                            'all',
                            'submitted',
                            'in_progress',
                            'approved',
                            'rejected',
                          ])
                            ChoiceChip(
                              label: Text(
                                s == 'all'
                                    ? 'All'
                                    : s.replaceAll('_', ' ').toUpperCase(),
                              ),
                              selected: _statusFilter == s,
                              onSelected:
                                  (_) => setState(() => _statusFilter = s),
                              selectedColor:
                                  _statusFilter == s
                                      ? _chipColor(s).withOpacity(0.2)
                                      : null,
                              labelStyle: TextStyle(
                                color:
                                    _statusFilter == s
                                        ? _chipColor(s)
                                        : Colors.grey.shade700,
                                fontWeight:
                                    _statusFilter == s
                                        ? FontWeight.bold
                                        : FontWeight.normal,
                                fontSize: 12,
                              ),
                            ),
                        ],
                      ),

                      const SizedBox(height: 12),

                      Row(
                        children: [
                          Expanded(
                            child: DropdownButtonFormField<int?>(
                              value: _yearFilter,
                              decoration: InputDecoration(
                                labelText: 'Year',
                                isDense: true,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 8,
                                ),
                              ),
                              items: [
                                const DropdownMenuItem(
                                  value: null,
                                  child: Text('All'),
                                ),
                                const DropdownMenuItem(
                                  value: 1,
                                  child: Text('Year 1'),
                                ),
                                const DropdownMenuItem(
                                  value: 2,
                                  child: Text('Year 2'),
                                ),
                                const DropdownMenuItem(
                                  value: 3,
                                  child: Text('Year 3'),
                                ),
                              ],
                              onChanged: (v) => setState(() => _yearFilter = v),
                            ),
                          ),

                          const SizedBox(width: 8),

                          Expanded(
                            child: DropdownButtonFormField<String?>(
                              value: _moduleFilter,
                              decoration: InputDecoration(
                                labelText: 'Module',
                                isDense: true,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 8,
                                ),
                              ),
                              items: [
                                const DropdownMenuItem(
                                  value: null,
                                  child: Text('All'),
                                ),
                                ...modules.map(
                                  (m) => DropdownMenuItem(
                                    value: m,
                                    child: Text(m),
                                  ),
                                ),
                              ],
                              onChanged:
                                  (v) => setState(() => _moduleFilter = v),
                            ),
                          ),

                          const SizedBox(width: 8),

                          InkWell(
                            onTap:
                                () => setState(
                                  () => _newestFirst = !_newestFirst,
                                ),
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 10,
                              ),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey.shade400),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    _newestFirst
                                        ? Icons.arrow_downward
                                        : Icons.arrow_upward,
                                    size: 16,
                                    color: Colors.indigo,
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    _newestFirst ? 'Newest' : 'Oldest',
                                    style: const TextStyle(
                                      fontSize: 12,
                                      color: Colors.indigo,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 12),

                Padding(
                  padding: const EdgeInsets.only(left: 4, bottom: 8),
                  child: Text(
                    '${filtered.length} application${filtered.length == 1 ? '' : 's'} found',
                    style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
                  ),
                ),

                if (filtered.isEmpty)
                  Container(
                    padding: const EdgeInsets.all(40),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      children: [
                        Icon(
                          Icons.inbox_outlined,
                          size: 60,
                          color: Colors.grey.shade400,
                        ),
                        const SizedBox(height: 12),
                        const Text('No applications found'),
                      ],
                    ),
                  ),

                ...filtered.map((app) {
                  final profile =
                      app['profiles'] as Map<String, dynamic>? ?? {};
                  final status = app['status'] ?? '';
                  final color = _statusColor(status);
                  final name =
                      '${profile['name'] ?? ''} ${profile['surname'] ?? ''}';
                  final number = profile['student_number']?.toString() ?? '';

                  return GestureDetector(
                    onTap: () => _showDetail(app),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.04),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: Colors.indigo.shade50,
                                child: Text(
                                  name.isNotEmpty ? name[0].toUpperCase() : 'U',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.indigo,
                                  ),
                                ),
                              ),

                              const SizedBox(width: 12),

                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      name.trim().isEmpty
                                          ? 'Unknown Student'
                                          : name,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      'No: $number  •  Year ${app['current_year_of_study'] ?? '-'}',
                                      style: TextStyle(
                                        color: Colors.grey.shade600,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: color.withOpacity(0.12),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  status.toUpperCase().replaceAll('_', ' '),
                                  style: TextStyle(
                                    color: color,
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),

                          const SizedBox(height: 10),

                          Row(
                            children: [
                              const Icon(
                                Icons.book_outlined,
                                size: 14,
                                color: Colors.grey,
                              ),
                              const SizedBox(width: 4),
                              Expanded(
                                child: Text(
                                  '${app['primary_module_code'] ?? ''}'
                                  '${(app['secondary_module_code'] ?? '').toString().isNotEmpty ? ' + ${app['secondary_module_code']}' : ''}',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey.shade700,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              const Icon(
                                Icons.calendar_today_outlined,
                                size: 13,
                                color: Colors.grey,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                _formatDate(app['created_at']),
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey.shade600,
                                ),
                              ),
                            ],
                          ),

                          const SizedBox(height: 12),

                          Row(
                            children: [
                              if (status != 'approved')
                                Expanded(
                                  child: FilledButton(
                                    onPressed:
                                        () => _updateStatus(
                                          app['id'],
                                          'approved',
                                        ),
                                    style: FilledButton.styleFrom(
                                      backgroundColor: Colors.green,
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 10,
                                      ),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                    ),
                                    child: const Text(
                                      'Approve',
                                      style: TextStyle(fontSize: 13),
                                    ),
                                  ),
                                ),

                              if (status != 'approved' && status != 'rejected')
                                const SizedBox(width: 8),

                              if (status != 'rejected')
                                Expanded(
                                  child: OutlinedButton(
                                    onPressed:
                                        () => _updateStatus(
                                          app['id'],
                                          'rejected',
                                        ),
                                    style: OutlinedButton.styleFrom(
                                      foregroundColor: Colors.red,
                                      side: const BorderSide(color: Colors.red),
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 10,
                                      ),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                    ),
                                    child: const Text(
                                      'Reject',
                                      style: TextStyle(fontSize: 13),
                                    ),
                                  ),
                                ),

                              const SizedBox(width: 8),

                              OutlinedButton(
                                onPressed: () => _showDetail(app),
                                style: OutlinedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 10,
                                    horizontal: 12,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                child: const Icon(
                                  Icons.visibility_outlined,
                                  size: 18,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                }),

                const SizedBox(height: 30),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _statCard(String label, String value, Color color) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Text(
              value,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(fontSize: 11, color: color)),
          ],
        ),
      ),
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 130,
            child: Text(
              label,
              style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  Widget _docButton(String label, String url) {
    final hasUrl = url.isNotEmpty;
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(
        Icons.picture_as_pdf,
        color: hasUrl ? Colors.indigo : Colors.grey,
      ),
      title: Text(label, style: const TextStyle(fontSize: 14)),
      subtitle: Text(
        hasUrl ? 'Tap to open' : 'Not uploaded',
        style: TextStyle(
          fontSize: 12,
          color: hasUrl ? Colors.grey.shade600 : Colors.red.shade300,
        ),
      ),
      trailing:
          hasUrl
              ? const Icon(Icons.open_in_new, color: Colors.indigo, size: 18)
              : null,
      onTap: hasUrl ? () => _openDocument(url) : null,
    );
  }

  Color _chipColor(String status) {
    switch (status) {
      case 'approved':
        return Colors.green;
      case 'rejected':
        return Colors.red;
      case 'in_progress':
        return Colors.blue;
      case 'submitted':
        return Colors.orange;
      default:
        return Colors.indigo;
    }
  }

  String _formatDate(String? raw) {
    if (raw == null) return '-';
    final dt = DateTime.tryParse(raw);
    if (dt == null) return '-';
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}
