import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../viewmodels/auth_viewmodel.dart';
import '../../viewmodels/application_viewmodel.dart';
import '../../core/routes/route_manager.dart';

class ApplicationFormScreen extends StatefulWidget {
  final String? applicationId;
  const ApplicationFormScreen({super.key, this.applicationId});

  @override
  State<ApplicationFormScreen> createState() => _ApplicationFormScreenState();
}

class _ApplicationFormScreenState extends State<ApplicationFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _supabase = Supabase.instance.client;

  bool _isEditMode = false;
  bool _loadingExisting = false;

  @override
  void initState() {
    super.initState();
    if (widget.applicationId != null) {
      _isEditMode = true;
      WidgetsBinding.instance.addPostFrameCallback(
        (_) => _loadExistingApplication(),
      );
    }
  }

  final TextEditingController _motivationController = TextEditingController();

  @override
  void dispose() {
    _motivationController.dispose();
    super.dispose();
  }

  Future<void> _loadExistingApplication() async {
    setState(() => _loadingExisting = true);

    await context.read<ApplicationViewModel>().getApplicationById(
      widget.applicationId!,
    );

    final app = context.read<ApplicationViewModel>().selectedApplication;

    if (app != null) {
      setState(() {
        _yearOfStudy = app.currentYearOfStudy;
        _primaryModuleCode = app.primaryModuleCode;
        _primaryModuleName = app.primaryModuleName;
        _secondaryModuleCode = app.secondaryModuleCode;
        _secondaryModuleName = app.secondaryModuleName;
        _cvURL = app.cvUrl;
        _transcriptURL = app.transcriptUrl;
        _cvFileName = app.cvUrl.isNotEmpty ? 'CV uploaded' : null;
        _transcriptFileName =
            app.transcriptUrl.isNotEmpty ? 'Transcript uploaded' : null;
        _motivation = app.motivation;
        _eligibilityConfirmed = app.eligibilityConfirmed;
        _motivationController.text = app.motivation;
      });
    }

    setState(() => _loadingExisting = false);
  }

  int _yearOfStudy = 1;

  String? _primaryModuleCode;
  String? _primaryModuleName;
  String? _secondaryModuleCode;
  String? _secondaryModuleName;

  String? _cvURL;
  String? _transcriptURL;
  String _motivation = '';
  bool _eligibilityConfirmed = false;

  bool _uploadingCv = false;
  bool _uploadingTranscript = false;
  String? _cvFileName;
  String? _transcriptFileName;

  final Map<int, List<Map<String, String>>> _modules = {
    1: [
      {'code': 'PIM', 'name': 'Personal Information Management'},
      {'code': 'LCS', 'name': 'Academic Literacy and Communication Studies'},
      {'code': 'ITE', 'name': 'Information Technology Essentials'},
      {'code': 'ITM', 'name': 'Information Technology Mathematics'},
      {'code': 'PSA', 'name': 'Problem Solving and Algorithms'},
      {'code': 'SOD1', 'name': 'Software Development'},
      {'code': 'INP', 'name': 'Internet Programming'},
    ],
    2: [
      {'code': 'DBS', 'name': 'Databases'},
      {'code': 'SOE2', 'name': 'Software Engineering'},
      {'code': 'SOD2', 'name': 'Software Development'},
      {'code': 'GUD', 'name': 'Graphical Design'},
      {'code': 'TPG2', 'name': 'Technical Programming'},
      {'code': 'WEB', 'name': 'Web Content Management'},
      {'code': 'INT', 'name': 'Internet Technologies'},
    ],
    3: [
      {'code': 'SOD3', 'name': 'Software Development'},
      {'code': 'SOE3', 'name': 'Software Engineering'},
      {'code': 'TPG3', 'name': 'Technical Programming'},
      {'code': 'CMN', 'name': 'Communication Networks'},
      {'code': 'ITS', 'name': 'Information Technology and Society'},
    ],
  };

  Future<Map<String, String>?> _showModulePicker({
    String title = 'Select Module',
    String? excludeCode,
  }) async {
    return showModalBottomSheet<Map<String, String>>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.75,
          maxChildSize: 0.95,
          builder: (_, scrollController) {
            return Column(
              children: [
                const SizedBox(height: 12),
                Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Divider(),
                Expanded(
                  child: ListView(
                    controller: scrollController,
                    children: [
                      for (final year in _modules.keys) ...[
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                          child: Text(
                            _yearLabel(year),
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: Colors.indigo.shade400,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                        for (final module in _modules[year]!)
                          ListTile(
                            enabled: module['code'] != excludeCode,
                            leading: CircleAvatar(
                              radius: 18,
                              backgroundColor: Colors.indigo.shade50,
                              child: Text(
                                module['code']!.substring(0, 2),
                                style: const TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.indigo,
                                ),
                              ),
                            ),
                            title: Text(module['code']!),
                            subtitle: Text(module['name']!),
                            onTap: () => Navigator.pop(ctx, module),
                          ),
                      ],
                    ],
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  String _yearLabel(int year) {
    switch (year) {
      case 1:
        return '1ST YEAR MODULES';
      case 2:
        return '2ND YEAR MODULES';
      case 3:
        return '3RD YEAR MODULES';
      default:
        return 'YEAR $year MODULES';
    }
  }

  Future<void> _pickAndUpload(String type) async {
    final userId = context.read<AuthViewModel>().currentUser?.userId;
    if (userId == null) return;

    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      withData: true,
    );

    if (result == null || result.files.isEmpty) return;

    final file = result.files.first;
    if (file.bytes == null) return;

    final fileName = file.name;
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final storagePath = '$userId/${type}_$timestamp.pdf';

    setState(() {
      if (type == 'cv') {
        _uploadingCv = true;
      } else {
        _uploadingTranscript = true;
      }
    });

    try {
      await _supabase.storage
          .from('documents')
          .uploadBinary(
            storagePath,
            file.bytes!,
            fileOptions: const FileOptions(
              contentType: 'application/pdf',
              upsert: true,
            ),
          );

      final publicUrl = _supabase.storage
          .from('documents')
          .getPublicUrl(storagePath);

      setState(() {
        if (type == 'cv') {
          _cvURL = publicUrl;
          _cvFileName = fileName;
        } else {
          _transcriptURL = publicUrl;
          _transcriptFileName = fileName;
        }
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Upload failed: ${e.toString()}')));
    } finally {
      setState(() {
        if (type == 'cv') {
          _uploadingCv = false;
        } else {
          _uploadingTranscript = false;
        }
      });
    }
  }

  bool get _canSubmit =>
      _primaryModuleCode != null &&
      _cvURL != null &&
      _transcriptURL != null &&
      _eligibilityConfirmed &&
      _motivation.trim().isNotEmpty;

  Future<void> _submit() async {
    if (!_canSubmit) return;

    final student = context.read<AuthViewModel>().currentUser;
    if (student == null) return;

    final vm = context.read<ApplicationViewModel>();
    bool success;

    if (_isEditMode) {
      success = await vm.updateApplication(
        applicationId: widget.applicationId!,
        primaryModuleCode: _primaryModuleCode!,
        primaryModuleName: _primaryModuleName!,
        secondaryModuleCode: _secondaryModuleCode ?? '',
        secondaryModuleName: _secondaryModuleName ?? '',
        cvURL: _cvURL!,
        transcriptURL: _transcriptURL!,
        motivation: _motivation,
      );
    } else {
      success = await vm.createApplication(
        studentId: student.id,
        yearOfStudy: _yearOfStudy,
        primaryModuleCode: _primaryModuleCode!,
        primaryModuleName: _primaryModuleName!,
        secondaryModuleCode: _secondaryModuleCode ?? '',
        secondaryModuleName: _secondaryModuleName ?? '',
        cvURL: _cvURL!,
        transcriptURL: _transcriptURL!,
        motivation: _motivation,
        eligibilityConfirmed: _eligibilityConfirmed,
      );
    }

    if (!mounted) return;

    if (success) {
      Navigator.pushReplacementNamed(context, RouteManager.home);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(vm.errorMessage ?? 'Failed to submit application'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      appBar: AppBar(
        title: Text(_isEditMode ? 'Edit Application' : 'New Application'),
        centerTitle: true,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _sectionLabel('Year of Study'),
              DropdownButtonFormField<int>(
                value: _yearOfStudy,
                decoration: _inputDecoration('Select your year'),
                items: const [
                  DropdownMenuItem(value: 1, child: Text('1st Year')),
                  DropdownMenuItem(value: 2, child: Text('2nd Year')),
                  DropdownMenuItem(value: 3, child: Text('3rd Year')),
                ],
                onChanged: (value) => setState(() => _yearOfStudy = value!),
              ),

              const SizedBox(height: 24),

              _sectionLabel('Primary Module *'),
              _modulePickerTile(
                label:
                    _primaryModuleCode != null
                        ? '$_primaryModuleCode - $_primaryModuleName'
                        : 'Tap to select a module',
                selected: _primaryModuleCode != null,
                onTap: () async {
                  final picked = await _showModulePicker(
                    title: 'Select Primary Module',
                    excludeCode: _secondaryModuleCode,
                  );
                  if (picked != null) {
                    setState(() {
                      _primaryModuleCode = picked['code'];
                      _primaryModuleName = picked['name'];
                    });
                  }
                },
              ),

              const SizedBox(height: 16),

              _sectionLabel('Secondary Module (Optional)'),
              _modulePickerTile(
                label:
                    _secondaryModuleCode != null
                        ? '$_secondaryModuleCode - $_secondaryModuleName'
                        : 'Tap to select a module (optional)',
                selected: _secondaryModuleCode != null,
                showClear: _secondaryModuleCode != null,
                onTap: () async {
                  final picked = await _showModulePicker(
                    title: 'Select Secondary Module',
                    excludeCode: _primaryModuleCode,
                  );
                  if (picked != null) {
                    setState(() {
                      _secondaryModuleCode = picked['code'];
                      _secondaryModuleName = picked['name'];
                    });
                  }
                },
                onClear:
                    () => setState(() {
                      _secondaryModuleCode = null;
                      _secondaryModuleName = null;
                    }),
              ),

              const SizedBox(height: 24),

              _sectionLabel('CV (PDF only) *'),
              _uploadTile(
                icon: Icons.description_outlined,
                label: _cvFileName ?? 'Upload your CV',
                uploaded: _cvURL != null,
                loading: _uploadingCv,
                onTap: () => _pickAndUpload('cv'),
              ),

              const SizedBox(height: 16),

              _sectionLabel('Academic Transcript (PDF only) *'),
              _uploadTile(
                icon: Icons.school_outlined,
                label: _transcriptFileName ?? 'Upload your transcript',
                uploaded: _transcriptURL != null,
                loading: _uploadingTranscript,
                onTap: () => _pickAndUpload('transcript'),
              ),

              const SizedBox(height: 24),

              _sectionLabel('Motivation *'),
              TextFormField(
                controller: _motivationController,
                maxLines: 5,
                decoration: _inputDecoration(
                  'Tell us why you want to be a student assistant...',
                ),
                onChanged: (val) => setState(() => _motivation = val),
              ),

              const SizedBox(height: 20),

              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.grey.shade200),
                ),
                child: CheckboxListTile(
                  value: _eligibilityConfirmed,
                  onChanged:
                      (_cvURL != null && _transcriptURL != null)
                          ? (val) => setState(
                            () => _eligibilityConfirmed = val ?? false,
                          )
                          : null,
                  title: const Text(
                    'I confirm I meet all requirements and the information provided is correct',
                    style: TextStyle(fontSize: 13),
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),

              if (_cvURL == null || _transcriptURL == null)
                Padding(
                  padding: const EdgeInsets.only(top: 6, left: 4),
                  child: Text(
                    'Upload CV and transcript to enable this checkbox',
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                  ),
                ),

              const SizedBox(height: 28),

              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _canSubmit ? _submit : null,
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: const Text(
                    'Submit Application',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ),

              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionLabel(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(
      text,
      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
    ),
  );

  InputDecoration _inputDecoration(String hint) => InputDecoration(
    hintText: hint,
    filled: true,
    fillColor: Colors.white,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(color: Colors.grey.shade200),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(color: Colors.grey.shade200),
    ),
  );

  Widget _modulePickerTile({
    required String label,
    required bool selected,
    required VoidCallback onTap,
    bool showClear = false,
    VoidCallback? onClear,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? Colors.indigo.shade300 : Colors.grey.shade200,
          ),
        ),
        child: Row(
          children: [
            Icon(
              Icons.book_outlined,
              color: selected ? Colors.indigo : Colors.grey,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  color: selected ? Colors.black87 : Colors.grey.shade500,
                ),
              ),
            ),
            if (showClear)
              GestureDetector(
                onTap: onClear,
                child: const Icon(Icons.close, size: 18, color: Colors.grey),
              )
            else
              const Icon(Icons.chevron_right, color: Colors.grey),
          ],
        ),
      ),
    );
  }

  Widget _uploadTile({
    required IconData icon,
    required String label,
    required bool uploaded,
    required bool loading,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: loading ? null : onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: uploaded ? Colors.green.shade300 : Colors.grey.shade200,
          ),
        ),
        child: Row(
          children: [
            Icon(
              uploaded ? Icons.check_circle_outline : icon,
              color: uploaded ? Colors.green : Colors.grey,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  color: uploaded ? Colors.black87 : Colors.grey.shade500,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
            if (loading)
              const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
            else
              Icon(
                uploaded ? Icons.edit_outlined : Icons.upload_outlined,
                size: 18,
                color: Colors.grey,
              ),
          ],
        ),
      ),
    );
  }
}
