import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../viewmodels/application_viewmodel.dart';
import '../../viewmodels/auth_viewmodel.dart';
import '../../core/routes/route_manager.dart';

class ApplicationDetailScreen extends StatefulWidget {
  final String applicationId;
  const ApplicationDetailScreen({super.key, required this.applicationId});

  @override
  State<ApplicationDetailScreen> createState() =>
      _ApplicationDetailScreenState();
}

class _ApplicationDetailScreenState extends State<ApplicationDetailScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ApplicationViewModel>().getApplicationById(
        widget.applicationId,
      );
    });
  }

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'approved':
        return Colors.green;
      case 'rejected':
        return Colors.red;
      case 'in_progress':
      case 'in progress':
        return Colors.blue;
      case 'submitted':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  IconData _statusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'approved':
        return Icons.verified;
      case 'rejected':
        return Icons.cancel_outlined;
      case 'in_progress':
      case 'in progress':
        return Icons.autorenew;
      case 'submitted':
        return Icons.schedule;
      default:
        return Icons.help_outline;
    }
  }

  String _statusDescription(String status) {
    switch (status.toLowerCase()) {
      case 'approved':
        return 'Congratulations! Your application has been approved.';
      case 'rejected':
        return 'Your application was not successful. Please review and resubmit.';
      case 'in_progress':
      case 'in progress':
        return 'Your application is currently being reviewed.';
      case 'submitted':
        return 'Your application has been received and is awaiting review.';
      default:
        return '';
    }
  }

  Future<void> _openDocument(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Could not open document')));
    }
  }

  Future<void> _confirmDelete(String applicationId) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder:
          (ctx) => AlertDialog(
            title: const Text('Delete Application'),
            content: const Text(
              'Are you sure you want to delete this application? This cannot be undone.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Cancel'),
              ),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: Colors.red),
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Delete'),
              ),
            ],
          ),
    );

    if (confirmed != true || !mounted) return;

    final vm = context.read<ApplicationViewModel>();
    final success = await vm.deleteApplication(applicationId);

    if (!mounted) return;

    if (success) {
      // refresh home and go back
      final studentId = context.read<AuthViewModel>().currentUser?.id ?? '';
      await context.read<ApplicationViewModel>().loadStudentApplications(
        studentId,
      );
      if (!mounted) return;
      Navigator.pushReplacementNamed(context, RouteManager.home);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(vm.errorMessage ?? 'Failed to delete application'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      appBar: AppBar(
        title: const Text('Application Details'),
        centerTitle: true,
        elevation: 0,
      ),
      body: Consumer<ApplicationViewModel>(
        builder: (context, vm, _) {
          if (vm.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          final app = vm.selectedApplication;
          if (app == null) {
            return const Center(child: Text('Application not found'));
          }

          final color = _statusColor(app.status);

          // editable only when submitted
          final isEditable = app.status.toLowerCase() == 'submitted';

          return SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: color),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: color.withOpacity(0.15),
                        child: Icon(_statusIcon(app.status), color: color),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              app.status.toUpperCase(),
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: color,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _statusDescription(app.status),
                              style: TextStyle(
                                fontSize: 12,
                                color: color.withOpacity(0.8),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                _sectionTitle('Selected Modules'),
                const SizedBox(height: 10),
                _infoCard(
                  icon: Icons.book_outlined,
                  title: 'Primary Module',
                  value: '${app.primaryModuleCode} - ${app.primaryModuleName}',
                ),
                const SizedBox(height: 10),
                _infoCard(
                  icon: Icons.book_outlined,
                  title: 'Secondary Module',
                  value:
                      app.hasSecondaryModule
                          ? '${app.secondaryModuleCode} - ${app.secondaryModuleName}'
                          : 'None selected',
                  muted: !app.hasSecondaryModule,
                ),

                const SizedBox(height: 24),

                _sectionTitle('Academic Information'),
                const SizedBox(height: 10),
                _infoCard(
                  icon: Icons.school_outlined,
                  title: 'Year of Study',
                  value: 'Year ${app.currentYearOfStudy}',
                ),

                const SizedBox(height: 24),

                _sectionTitle('Supporting Documents'),
                const SizedBox(height: 10),
                _documentTile(
                  title: 'CV',
                  url: app.cvUrl,
                  icon: Icons.picture_as_pdf,
                ),
                _documentTile(
                  title: 'Academic Transcript',
                  url: app.transcriptUrl,
                  icon: Icons.school,
                ),

                const SizedBox(height: 24),

                _sectionTitle('Motivation'),
                const SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(
                    app.motivation,
                    style: const TextStyle(height: 1.5),
                  ),
                ),

                const SizedBox(height: 30),

                if (app.status.toLowerCase() == 'rejected') ...[
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed:
                          () => Navigator.pushNamed(
                            context,
                            RouteManager.applicationForm,
                            arguments: app.id,
                          ),
                      icon: const Icon(Icons.refresh),
                      label: const Text('Fix & Resubmit'),
                      style: FilledButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                ],

                if (isEditable) ...[
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed:
                          () => Navigator.pushNamed(
                            context,
                            RouteManager.applicationForm,
                            arguments: app.id,
                          ),
                      icon: const Icon(Icons.edit),
                      label: const Text('Edit Application'),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                ],

                if (isEditable)
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () => _confirmDelete(app.id),
                      icon: const Icon(Icons.delete_outline, color: Colors.red),
                      label: const Text(
                        'Delete Application',
                        style: TextStyle(color: Colors.red),
                      ),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        side: const BorderSide(color: Colors.red),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                    ),
                  ),

                const SizedBox(height: 40),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _sectionTitle(String title) => Text(
    title,
    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
  );

  Widget _infoCard({
    required IconData icon,
    required String title,
    required String value,
    bool muted = false,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Icon(icon, color: muted ? Colors.grey.shade400 : Colors.indigo),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: muted ? Colors.grey.shade400 : Colors.black87,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _documentTile({
    required String title,
    required String url,
    required IconData icon,
  }) {
    final hasFile = url.isNotEmpty;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: hasFile ? Colors.indigo.shade100 : Colors.grey.shade200,
        ),
      ),
      child: ListTile(
        leading: Icon(
          icon,
          color: hasFile ? Colors.indigo : Colors.grey.shade400,
        ),
        title: Text(title),
        subtitle: Text(
          hasFile ? 'Tap to view' : 'Not uploaded',
          style: TextStyle(
            color: hasFile ? Colors.grey.shade600 : Colors.red.shade300,
            fontSize: 12,
          ),
        ),
        trailing:
            hasFile
                ? const Icon(Icons.open_in_new, color: Colors.indigo, size: 18)
                : null,
        onTap: hasFile ? () => _openDocument(url) : null,
      ),
    );
  }
}
