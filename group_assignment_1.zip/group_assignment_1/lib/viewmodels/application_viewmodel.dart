import 'package:flutter/material.dart';
import '../models/application_model.dart';
import '../services/application_service.dart';

class ApplicationViewModel extends ChangeNotifier {
  final ApplicationService _service = ApplicationService();

  List<ApplicationModel> _applications = [];
  bool _isLoading = false;
  String? _errorMessage;

  List<Map<String, dynamic>> _allApplications = [];
  List<Map<String, dynamic>> get allApplications => _allApplications;

  List<ApplicationModel> get applications => _applications;
  bool get isLoading => _isLoading;
  bool get hasApplication => _applications.isNotEmpty;
  String? get errorMessage => _errorMessage;
  ApplicationModel? selectedApplication;

  Future<void> loadStudentApplications(String studentId) async {
    if (studentId.isEmpty) return;

    _setLoading(true);

    try {
      _applications = await _service.fetchStudentApplications(studentId);
      _errorMessage = null;
    } catch (e) {
      _errorMessage = e.toString();
    }

    _setLoading(false);
  }

  Future<bool> createApplication({
    required String studentId,
    required int yearOfStudy,
    required String primaryModuleCode,
    required String primaryModuleName,
    required String secondaryModuleCode,
    required String secondaryModuleName,
    required String cvURL,
    required String transcriptURL,
    required String motivation,
    required bool eligibilityConfirmed,
  }) async {
    _setLoading(true);

    try {
      final success = await _service.createApplication(
        studentId: studentId,
        yearOfStudy: yearOfStudy,
        primaryModuleCode: primaryModuleCode,
        primaryModuleName: primaryModuleName,
        secondaryModuleCode: secondaryModuleCode,
        secondaryModuleName: secondaryModuleName,
        cvURL: cvURL,
        transcriptURL: transcriptURL,
        eligibilityConfirmed: eligibilityConfirmed,
        motivation: motivation,
      );

      if (success) {
        await loadStudentApplications(studentId);
      }

      return success;
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> updateApplication({
    required String applicationId,
    required String primaryModuleCode,
    required String primaryModuleName,
    required String secondaryModuleCode,
    required String secondaryModuleName,
    required String cvURL,
    required String transcriptURL,
    required String motivation,
  }) async {
    _setLoading(true);

    try {
      final success = await _service.updateApplication(
        applicationId: applicationId,
        primaryModuleCode: primaryModuleCode,
        primaryModuleName: primaryModuleName,
        secondaryModuleCode: secondaryModuleCode,
        secondaryModuleName: secondaryModuleName,
        cvURL: cvURL,
        transcriptURL: transcriptURL,
        motivation: motivation,
      );

      return success;
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> deleteApplication(String applicationId) async {
    _setLoading(true);

    try {
      final success = await _service.deleteApplication(applicationId);

      if (success) {
        _applications.removeWhere((a) => a.id == applicationId);
        notifyListeners();
      }

      return success;
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  Future<void> getApplicationById(String id) async {
    _setLoading(true);

    selectedApplication = await _service.getApplicationById(id);

    _setLoading(false);
    notifyListeners();
  }

  Future<void> loadAllApplications() async {
    _setLoading(true);
    try {
      _allApplications = await _service.fetchAllApplications();
      _errorMessage = null;
    } catch (e) {
      _errorMessage = e.toString();
    }
    _setLoading(false);
  }

  Future<bool> approveApplication(String applicationId) async {
    try {
      final success = await _service.updateApplicationStatus(
        applicationId: applicationId,
        status: 'approved',
      );
      if (success) await loadAllApplications();
      return success;
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    }
  }

  Future<bool> rejectApplication(String applicationId) async {
    try {
      final success = await _service.updateApplicationStatus(
        applicationId: applicationId,
        status: 'rejected',
      );
      if (success) await loadAllApplications();
      return success;
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    }
  }

  Future<bool> adminDeleteApplication(String applicationId) async {
    try {
      final success = await _service.deleteApplication(applicationId);
      if (success) {
        _allApplications.removeWhere((a) => a['id'] == applicationId);
        notifyListeners();
      }
      return success;
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    }
  }
}
