import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';
import 'package:image_picker/image_picker.dart';

class AuthViewModel extends ChangeNotifier {
  final AuthService _authService = AuthService();

  UserModel? _currentUser;
  bool _isLoading = false;
  String? _errorMessage;

  UserModel? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get isLoggedIn => _currentUser != null;
  bool get isAdmin => _currentUser?.isAdmin ?? false;

  Future<bool> login(String email, String password) async {
    _setLoading(true);
    _errorMessage = null;

    try {
      final user = await _authService.signIn(email, password);

      if (user != null) {
        _currentUser = user;
        notifyListeners();
        return true;
      } else {
        _errorMessage = 'Invalid credentials. Please try again.';

        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'Login failed: ${e.toString()}';

      notifyListeners();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> register({
    required String name,
    required String surname,
    required int studentNumber,
    required String email,
    required String password,
  }) async {
    _setLoading(true);
    _errorMessage = null;

    try {
      final user = await _authService.signUp(
        email: email,
        password: password,
        name: name,
        surname: surname,
        studentNumber: studentNumber,
      );

      if (user != null) {
        _currentUser = user;

        notifyListeners();
        return true;
      } else {
        _errorMessage = 'Registration failed. Please try again.';

        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'Registration failed: ${e.toString()}';

      notifyListeners();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<void> logout() async {
    _setLoading(true);

    try {
      await _authService.signOut();

      _currentUser = null;

      notifyListeners();
    } catch (e) {
      _errorMessage = 'Logout failed: ${e.toString()}';

      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  Future<void> loadCurrentUser() async {
    try {
      final user = await _authService.getCurrentProfile();

      _currentUser = user;

      notifyListeners();
    } catch (e) {
      _errorMessage = 'Failed to load user: ${e.toString()}';

      notifyListeners();
    }
  }

  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  Future<void> uploadAvatar(XFile imageFile) async {
    if (_currentUser == null) return;

    _setLoading(true);
    _errorMessage = null;

    try {
      final url = await _authService.uploadAvatar(
        _currentUser!.userId,
        imageFile,
      );

      if (url != null) {
        // rebuild the user model with the new avatar URL
        _currentUser = UserModel(
          id: _currentUser!.id,
          userId: _currentUser!.userId,
          name: _currentUser!.name,
          surname: _currentUser!.surname,
          studentNumber: _currentUser!.studentNumber,
          email: _currentUser!.email,
          role: _currentUser!.role,
          avatarUrl: url,
          createdAt: _currentUser!.createdAt,
        );
        notifyListeners();
      }
    } catch (e) {
      _errorMessage = 'Failed to upload avatar: ${e.toString()}';
      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }
}
